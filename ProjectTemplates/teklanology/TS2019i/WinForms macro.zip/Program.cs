﻿using System;

namespace Tekla.Technology.Akit
{
    public class IScript
    {

    }
}