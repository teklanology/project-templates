﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

using Tekla.Structures;
using Tekla.Structures.Drawing;
using TSD = Tekla.Structures.Drawing;
using Tekla.Structures.Geometry3d;
using TSG = Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using TSM = Tekla.Structures.Model;
using TSMUI = Tekla.Structures.Model.UI;

namespace Tekla.Technology.Akit.UserScript
{
    static class Script
    {
        public static void Run(Tekla.Technology.Akit.IScript akit)
        {
            
        }
    }
}
